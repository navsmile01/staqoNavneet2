package org.ex.staqo.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import org.ex.staqo.R;
import org.ex.staqo.model.EmployeeModel;

import java.util.ArrayList;
import java.util.List;

public class EmployeeAdapter extends RecyclerView.Adapter<EmployeeAdapter.ViewHolder> {
    EmployeeModel feedItem;
    private Context context;
    private ArrayList<EmployeeModel> feedItemList;

    public EmployeeAdapter(Context context, ArrayList<EmployeeModel> feedItemList) {
        this.context = context;
        this.feedItemList = feedItemList;
    }

    @Override
    public EmployeeAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.single_row_employee_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        feedItem = feedItemList.get( position );
        holder.tv_name.setText(feedItem.getFirst_name()+" "+feedItem.getLast_name());
        holder.tv_email.setText(String.valueOf(feedItem.getEmail()));
       // holder.textYear.setText(String.valueOf(movie.getId()));


        if (feedItem.getImage_url() != null && !feedItem.getImage_url().isEmpty()) {

            if (feedItem.getImage_url().length() > 0) {

                Log.v( "EmployeeAdapter", "item image=" + feedItem.getImage_url() );
                Picasso.with( context )  //Here, this is context.
                        .load( feedItem.getImage_url() )  //Url of the image to load.
                       // .placeholder( R.drawable.no_image )   // optional
                        .into( holder.img_view );
            }else {
               // holder.img_view.setImageResource( R.drawable.no_image );
            }
        }else {
           // holder.img_view.setImageResource( R.drawable.no_image );
        }



    }

    @Override
    public int getItemCount() {
        return feedItemList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tv_name, tv_email;//, textYear;
        public ImageView img_view;

        public ViewHolder(View itemView) {
            super(itemView);

            tv_name = itemView.findViewById(R.id.tv_name);
            tv_email = itemView.findViewById(R.id.tv_email);
          //  textYear = itemView.findViewById(R.id.main_year);
            img_view = itemView.findViewById(R.id.img_view);
        }
    }

}
