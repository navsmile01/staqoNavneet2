package org.ex.staqo.utils;

import android.content.Context;
import android.provider.Settings;
import android.widget.RatingBar;
import java.util.Random;
import java.util.regex.Pattern;


public class Common {

    public static Common obj;

    public static final String BASE_URL = "https://reqres.in/api/users";
    private static final String ALLOWED_CHARACTERS = "01234JBNMIOP56789qwerJBNMIOPtyuiopasdfghjklzVTYxcvbnm9a8v7g4h5m6r1o2k30lzxuqwstCRFVTYUGHJBfbncm1p6DCYUi2u3ygvewq7RFVT8pouytr632MIOPllh21mxza013kmntrwQWASZXEGHKL";
    public static String current_secure_key = "";


    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;

    float ratedValue1 = 0;
    static RatingBar ratingBar1;

    public Common() {

    }

    public static Common getInstance() {

        if (obj == null) {

            obj = new Common();
        }
        return obj;

    }

    public final Pattern EMAIL_ADDRESS_PATTERN = Pattern.compile(
            "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
                    "\\@" +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
                    "(" +
                    "\\." +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
                    ")+" );


    public boolean checkEmail(String email) {
        return EMAIL_ADDRESS_PATTERN.matcher( email ).matches();
    }


    public static String getRandomString(final int sizeOfRandomString) {
        final Random random = new Random();
        final StringBuilder sb = new StringBuilder( sizeOfRandomString );
        for (int i = 0; i < sizeOfRandomString; ++i)
           sb.append( ALLOWED_CHARACTERS.charAt( random.nextInt( ALLOWED_CHARACTERS.length())));
        return sb.toString();
    }


    public static String getSecureID(Context context) {
        String android_id = Settings.Secure.getString( context.getContentResolver(),
                Settings.Secure.ANDROID_ID );
        return android_id;
    }




}


