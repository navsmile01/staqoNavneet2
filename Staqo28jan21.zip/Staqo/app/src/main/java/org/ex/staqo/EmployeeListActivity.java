package org.ex.staqo;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.Cache;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.ex.staqo.adapter.EmployeeAdapter;
import org.ex.staqo.model.EmployeeModel;
import org.ex.staqo.utils.Common;
import org.ex.staqo.utils.PostVolleyJsonRequest;
import org.ex.staqo.utils.VolleyJsonRespondsListener;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class EmployeeListActivity extends AppCompatActivity implements VolleyJsonRespondsListener {


    int TotalPage = 1;
    int pageCount = 1;

    private RecyclerView mList;

    private LinearLayoutManager linearLayoutManager;
    private DividerItemDecoration dividerItemDecoration;


    ArrayList<EmployeeModel> arr_employee = new ArrayList<>();
    private EmployeeAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mList = findViewById(R.id.main_list);

        arr_employee = new ArrayList<>();
        adapter = new EmployeeAdapter(getApplicationContext(), arr_employee);

        linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        dividerItemDecoration = new DividerItemDecoration(mList.getContext(), linearLayoutManager.getOrientation());

        mList.setHasFixedSize(true);
        mList.setLayoutManager(linearLayoutManager);
        mList.addItemDecoration(dividerItemDecoration);
        mList.setAdapter(adapter);

        arr_employee = new ArrayList<EmployeeModel>();

        // Lookup the swipe container view
        SwipeRefreshLayout swipeContainer = (SwipeRefreshLayout) findViewById(R.id.swipeContainer);
        // Setup refresh listener which triggers new data loading
        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Your code to refresh the list here.
                // Make sure you call swipeContainer.setRefreshing(false)
                // once the network request has completed successfully.
                if (pageCount <= TotalPage) {
                    pageCount = pageCount + 1;
                    reqEmployeeData(EmployeeListActivity.this,  pageCount);
                }
                swipeContainer.setRefreshing(false);

            }

        });
        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);



        reqEmployeeData(this,  pageCount);
    }

    public void reqEmployeeData(final Activity activity, final int pageCount) {
        Map<String, String> params = new HashMap<>();
       // params.put( "user_id", Prefs.getInstance().user_id );

        new PostVolleyJsonRequest( activity, EmployeeListActivity.this, "employee_data", Common.BASE_URL + "?page=" + pageCount, params );

    }



    public void getEmployeeData(JSONObject jsonObject) {
        try {


            JSONArray jsonArray = jsonObject.getJSONArray("data");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                Log.i("chhhhh", " " + jsonObject1);


                EmployeeModel model_brandDetails = new EmployeeModel(jsonObject1.getInt("id"),
                        jsonObject1.getString("email"),
                        jsonObject1.getString("first_name"),
                        jsonObject1.getString("last_name"),
                        jsonObject1.getString("avatar"));
                arr_employee.add(model_brandDetails);
            }

            EmployeeAdapter allNotificationDetailAdapter = new EmployeeAdapter(this, arr_employee);
            mList.setAdapter(allNotificationDetailAdapter);


        } catch (JSONException jsonexception) {

        }
    }


    @Override
    public void onSuccessJson(JSONObject response, String type) {

        switch (type) {

            case "employee_data":

                try {
                    //  mTextView.setText(response.toString(5));
                    Log.i("EmployeeList", "getEmployeeData " + response.toString(1));

                      /* {"page":1,"per_page":6,"total":12,"total_pages":2,"data":[
              {"id":1,"email":"george.bluth@reqres.in","first_name":"George","last_name":"Bluth","avatar":"https://reqres.in/img/faces/1-image.jpg"},
              {"id":2,"email":"janet.weaver@reqres.in","first_name":"Janet","last_name":"Weaver","avatar":"https://reqres.in/img/faces/2-image.jpg"},
              "avatar":"https://reqres.in/img/faces/6-image.jpg"}],"support":{"url":"https://reqres.in/#support-heading","text":"To keep ReqRes free, contributions towards server costs are appreciated!"}}*/

                    Log.v("EmployeeList", "params 111=" + response.getString("total_pages"));
                    TotalPage = response.getInt("total_pages");


                    getEmployeeData(response);


                } catch (JSONException e) {
                    // mTextView.setText(e.toString());
                }


        }

    }

    @Override
    public void onFailureJson(int responseCode, String responseMessage) {

    }

    @Override
    public Response<JSONObject> onCacheParseNetworkResponse(NetworkResponse response, String type) {

        try {
            Cache.Entry cacheEntry = HttpHeaderParser.parseCacheHeaders(response);
            if (cacheEntry == null) {
                cacheEntry = new Cache.Entry();
            }
            final long cacheHitButRefreshed = 3 * 60 * 1000; // in 3 minutes cache will be hit, but also refreshed on background
            final long cacheExpired = 24 * 60 * 60 * 1000; // in 24 hours this cache entry expires completely
            long now = System.currentTimeMillis();
            final long softExpire = now + cacheHitButRefreshed;
            final long ttl = now + cacheExpired;
            cacheEntry.data = response.data;
            cacheEntry.softTtl = softExpire;
            cacheEntry.ttl = ttl;
            String headerValue;
            headerValue = response.headers.get("Date");
            if (headerValue != null) {
                cacheEntry.serverDate = HttpHeaderParser.parseDateAsEpoch(headerValue);
            }
            headerValue = response.headers.get("Last-Modified");
            if (headerValue != null) {
                cacheEntry.lastModified = HttpHeaderParser.parseDateAsEpoch(headerValue);
            }
            cacheEntry.responseHeaders = response.headers;
            final String jsonString = new String(response.data,
                    HttpHeaderParser.parseCharset(response.headers));
            return Response.success(new JSONObject(jsonString), cacheEntry);
        } catch (UnsupportedEncodingException e) {
            return Response.error(new ParseError(e));
        } catch (JSONException e) {
            return Response.error(new ParseError(e));
        }

    }
}
