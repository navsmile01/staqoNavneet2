package org.ex.staqo.utils;

import com.android.volley.NetworkResponse;
import com.android.volley.Response;

import org.json.JSONObject;

/**
 * Created by weblink on 07/01/19.
 */

public interface VolleyJsonRespondsListener {

    public void onSuccessJson(JSONObject result, String type);
    public void onFailureJson(int responseCode, String responseMessage);
    public Response<JSONObject> onCacheParseNetworkResponse(NetworkResponse response, String type);
}
