package org.ex.staqo.utils;

import android.app.Activity;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.Cache;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by weblink on 5/9/18.
 */

public class PostVolleyJsonRequest {

    private String type;
    private Activity act;
    private VolleyJsonRespondsListener volleyJsonRespondsListener;
    private String networkurl;
    private JSONObject jsonObject = null;
    Map<String, String> params = new HashMap<>();


    public PostVolleyJsonRequest(Activity act, VolleyJsonRespondsListener volleyJsonRespondsListener, String type, String netnetworkUrl, Map<String, String> params) {
        this.act = act;
        this.volleyJsonRespondsListener = volleyJsonRespondsListener;
        this.type = type;
        this.networkurl = netnetworkUrl;
        this.params = params;
        Log.v( "PostVolleyJsonRequest", "params = " + params );
        requestCall();
    }

    void requestCall(){

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest( networkurl, null,new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                volleyJsonRespondsListener.onSuccessJson( response, type );


            }
        },
         new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                try {
                    NetworkResponse response = error.networkResponse;
                    if (response != null) {
                        int code = response.statusCode;

                        String errorMsg = new String( response.data );
                        Log.e( "response", "response" + errorMsg );
                        try {
                            jsonObject = new JSONObject( errorMsg );
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        String msg = jsonObject.optString( "message" );
                        volleyJsonRespondsListener.onFailureJson( code, msg );
                    } else {
                        String errorMsg = error.getMessage();
                        volleyJsonRespondsListener.onFailureJson( 0, errorMsg );
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        ) {
            @Override
          //  public Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
            public Response<JSONObject> parseNetworkResponse(NetworkResponse response) {

                return  volleyJsonRespondsListener.onCacheParseNetworkResponse( response, type );

            }

            @Override
            protected void deliverResponse(JSONObject response) {
                super.deliverResponse(response);
            }

            @Override
            public void deliverError(VolleyError error) {
                super.deliverError(error);
            }

            @Override
            protected VolleyError parseNetworkError(VolleyError volleyError) {
                return super.parseNetworkError(volleyError);
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                return super.getHeaders();
            }


            @Override
            protected Map <String, String> getParams() throws AuthFailureError {
               /* params.put( "device_id", Common.getSecureID( act ) );
                params.put( "app_id", Common.getSecureID( act ) );
                params.put( "fcm_id", Common.getSecureID( act ) );

                params.put( "app_type", "android" );
                params.put( "wl_keys", Common.current_secure_key );
                params.put("site_language_id", Common.APPLanguage);*/
                Log.v( "requestCall", "params = " + params );
                return params;
            }
        };






        // MySingleton.getInstance(this).addToRequestQueue(jsonObjectRequest);

        RequestQueue requestQueue = Volley.newRequestQueue(act);
        requestQueue.add(jsonObjectRequest);

    }



}
